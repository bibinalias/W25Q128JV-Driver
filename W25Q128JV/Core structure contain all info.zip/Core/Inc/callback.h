/*
 * callback.h
 *
 *  Created on: 17-Nov-2020
 *      Author: Bibin
 */

#ifndef INC_CALLBACK_H_
#define INC_CALLBACK_H_


enum DATA_TRANSFER{
	END=10,
	START

};

enum STATUS_MATCH{
	MATCH=2,
	NOT_MATCH
};


#endif /* INC_CALLBACK_H_ */
