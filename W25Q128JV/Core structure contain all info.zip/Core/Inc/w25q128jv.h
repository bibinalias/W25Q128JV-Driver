/*
 * W25Q128JV_QSPI_Instructions.h
 *
 *  Created on: 13-Nov-2020
 *      Author: Bibin
 */

#ifndef INC_W25Q128JV_H_
#define INC_W25Q128JV_H_
#include "inttypes.h"
#include "qspi_structure.h"


typedef enum
{

	W25Q128JV_INS_WRITE_ENABLE	=0X06,
	W25Q128JV_INS_READ_STATUS_REG_1	=0X05,
	W25Q128JV_INS_READ_STATUS_REG_2	=0X35,
	W25Q128JV_INS_READ_STATUS_REG_3	=0X15


}EW25Q128JV_Instruction;

typedef enum
{
	ERR_W25Q128JV_NO_ERROR			=	0,
	ERR_W25Q128JV_INIT_FAIL			=	0x1001,
	ERR_W25Q128JV_QSPI_INIT_FAIL,
	ERR_W25Q128JV_QSPI_TX_FAIL,
	ERR_W25Q128JV_QSPI_RX_FAIL,
	ERR_W25Q128JV_QSPI_CMD_FAIL,
	ERR_W25Q128JV_QSPI_TXRX_FAIL,
	ERR_W25Q128JV_JEDEC_ID_MISMATCH,
	ERR_W25Q128JV_CMD_TOUT,
	ERR_W25Q128JV_UNKNOWN_ERASE_CMD,
	ERR_W25Q128JV_REG_NO_OUT_OF_RANGE,
	ERR_W25Q128JV_REG_SPE_CMD_FRAME_ERR,
	ERR_W25Q128JV_REG_SPE_CMD_ERR,
	ERR_W25Q128JV_REG_SPI_COM_ERR,
}EW25Q128JVErrorCode;

typedef enum
{
	STATUS_REG_1=1,
	STATUS_REG_2,
	STATUS_REG_3

}EW25Q128JVStatusRegister;
typedef struct
{

	EW25Q128JVErrorCode (*qspi_command_send)(TS_QSPI_CommandTypeDef *sCommand,uint32_t timeout);
	EW25Q128JVErrorCode (*qspi_receive)(uint8_t *pRdBuffer,uint32_t timeout);



}SW25Q128JV_Handle;
//EW25Q128JVErrorCode w25q128jv_write_enable(SW25Q128JV_Handle *pHdle);
EW25Q128JVErrorCode w25q128jv_write_enable(SW25Q128JV_Handle *pHdle);
#endif /* INC_W25Q128JV_H_ */
