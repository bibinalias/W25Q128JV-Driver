/*
 * W25Q128JV_QSPI_Instructions.c
 *
 *  Created on: 13-Nov-2020
 *      Author: Bibin
 */


#include "w25q128jv.h"
#include "inttypes.h"
#include "qspi_structure.h"




EW25Q128JVErrorCode w25q128jv_write_enable(SW25Q128JV_Handle *pHdle)
{

	EW25Q128JVErrorCode err_code = ERR_W25Q128JV_NO_ERROR;
	TS_QSPI_CommandTypeDef sCommand;

	uint32_t timeout;//Crash Protection Timeout



	timeout=10;
	sCommand.AddressSize       = TS_QSPI_ADDRESS_24_BITS;
	sCommand.AlternateByteMode = TS_QSPI_ALTERNATE_BYTES_NONE;
	sCommand.AlternateBytesSize=TS_QSPI_ALTERNATE_BYTES_8_BITS;
	sCommand.Instruction = (uint32_t)W25Q128JV_INS_WRITE_ENABLE;
	sCommand.AddressMode = TS_QSPI_ADDRESS_NONE;
	sCommand.Address     = 0x0;
	sCommand.DataMode    = TS_QSPI_DATA_NONE;
	sCommand.DummyCycles = 0;
	sCommand.NbData=0;
	sCommand.InstructionMode   = TS_QSPI_INSTRUCTION_1_LINE;
	sCommand.DdrMode           = TS_QSPI_DDR_MODE_DISABLE;
	sCommand.DdrHoldHalfCycle  = TS_QSPI_DDR_HHC_ANALOG_DELAY;
	sCommand.SIOOMode          = TS_QSPI_SIOO_INST_EVERY_CMD;
	sCommand.AlternateBytes	=	0x00;


	err_code	=	(*(pHdle->qspi_command_send))( &sCommand,timeout);


	return err_code;

}


EW25Q128JVErrorCode w25q128jv_read_stat_reg(SW25Q128JV_Handle *pHdle,EW25Q128JVStatusRegister stat_reg,uint8_t *pRegVal)
{

	EW25Q128JVErrorCode err_code = ERR_W25Q128JV_NO_ERROR;
	TS_QSPI_CommandTypeDef sCommand;

	uint32_t timeout;//Crash Protection Timeout



	timeout=10;
	sCommand.AddressSize       = TS_QSPI_ADDRESS_24_BITS;
	sCommand.AlternateByteMode = TS_QSPI_ALTERNATE_BYTES_NONE;
	sCommand.AlternateBytesSize=TS_QSPI_ALTERNATE_BYTES_8_BITS;
	sCommand.Instruction = (uint32_t)(stat_reg==STATUS_REG_1)?W25Q128JV_INS_READ_STATUS_REG_1:((stat_reg==STATUS_REG_2)?W25Q128JV_INS_READ_STATUS_REG_2:W25Q128JV_INS_READ_STATUS_REG_3);
	sCommand.AddressMode = TS_QSPI_ADDRESS_NONE;
	sCommand.Address     = 0x0;
	sCommand.DataMode    = TS_QSPI_DATA_1_LINE;
	sCommand.DummyCycles = 0;
	sCommand.NbData=1;
	sCommand.InstructionMode   = TS_QSPI_INSTRUCTION_1_LINE;
	sCommand.DdrMode           = TS_QSPI_DDR_MODE_DISABLE;
	sCommand.DdrHoldHalfCycle  = TS_QSPI_DDR_HHC_ANALOG_DELAY;
	sCommand.SIOOMode          = TS_QSPI_SIOO_INST_EVERY_CMD;
	sCommand.AlternateBytes	=	0x00;


	err_code	=	(*(pHdle->qspi_command_send))( &sCommand,timeout);

	if(err_code	==	ERR_W25Q128JV_NO_ERROR)
	{
		err_code	=(*(pHdle->qspi_receive))(pRegVal,timeout);
	}


	return err_code;

}
